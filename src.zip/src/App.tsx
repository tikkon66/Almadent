import React from 'react';
import './App.css';
import { Dashboard } from './components/Dashboard/Dashboard';
// import { createClient, deleteClient } from './service/clients';
// import Confirm from './components/CallBack/Confirm';


export const App: React.FC = () => {

  // async function clientCreate() {

  //   await createClient({
  //     fullName: 'Иван Иванов',
  //     phone: '+7700124567',
  //     email: 'ivan@gmil.com',
  //     note: 'Постоянный клиент',
  //   });
  // }

  return (
    <>
    <Dashboard/>


      {/* <Confirm
        text="Добавить клиента?"
        successText="Клиент добавлен!"
        action={() => clientCreate()}
      >
        <button>Добавить клиента</button>
      </Confirm>

      <Confirm
        text="Удалить клиента?"
        successText="Клиент удален!"
        action={() => deleteClient(7)}
      >
        <button>Удалить клиента</button>
      </Confirm> */}
    </>
  );
};


export default App
