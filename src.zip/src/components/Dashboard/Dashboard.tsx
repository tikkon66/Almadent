import React, { useState } from 'react';
import { Sidebar } from '../Sidebar/Sidebar';
import { AppointmentsPage } from '../AppointmentsPage/AppointmentsPage';
// import { AppointmentModal } from '../AppointmentsPage/AppointmentModal/AppointmentModal';
import './Dashboard.css';
import ClientsPage from '../ClientsPage/ClientsPage';
import StatisticsPage from '../StatisticsPage/StatisticsPage';
import BranchesPage from '../BranchesPage/BranchesPage';
import EmployeesPage from '../EmployeesPage/EmployeesPage';
import ServicesPage from '../ServicesPage/ServicesPage';


export const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('appointments');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);

  const handleSuccess = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'appointments':
        return (
          <AppointmentsPage
            onOpenModal={() => setIsModalOpen(true)}
            refreshTrigger={refreshTrigger}
          />
        );

      case 'stats':
        return <StatisticsPage />;

      case 'clients':
        return <ClientsPage />;

      case 'branches':
        return <BranchesPage />;

      case 'employees':
        return <EmployeesPage />;

      case 'services':
        return <ServicesPage />;

      default:
        return (
          <AppointmentsPage
            onOpenModal={() => setIsModalOpen(true)}
            refreshTrigger={refreshTrigger}
          />
        );
    }
  };

  return (
    <div className="dashboard">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      <main className="dashboard-main">
        {renderContent()}
      </main>

      {/* <AppointmentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={handleSuccess}
      /> */}
    </div>
  );
};

export default Dashboard;