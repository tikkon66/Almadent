import React, { useEffect, useState } from 'react';
import {
  getAppointments,
  getBranches,
  getEmployeesByBranch,
  getServicesByBranch,
  createAppointment,
} from '../../service/appointments';
import type {
  Appointment,
  Branch,
  Employee,
  Service,
} from '../../service/appointments';
import './AppointmentsPage.css';

interface AppointmentsPageProps {
  onOpenModal?: () => void;
  refreshTrigger?: number;
}

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

// Встроенный компонент модального окна для прямого вызова
const AppointmentModalInternal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [services, setServices] = useState<Service[]>([]);

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    branchId: 0,
    employeeId: 0,
    serviceId: 0,
    date: new Date().toISOString().slice(0, 16),
    status: 'booked' as const,
    price: 0,
    duration: 60,
    comment: '',
    clientNote: '',
  });

  useEffect(() => {
    if (isOpen) {
      getBranches().then((b) => {
        setBranches(b);
        if (b.length > 0) {
          setFormData((prev) => ({ ...prev, branchId: b[0].id }));
        }
      });
    }
  }, [isOpen]);

  useEffect(() => {
    if (formData.branchId) {
      getEmployeesByBranch(formData.branchId).then(setEmployees);
      getServicesByBranch(formData.branchId).then(setServices);
    }
  }, [formData.branchId]);

  if (!isOpen) return null;

  const handleServiceChange = (serviceId: number) => {
    const selected = services.find((s) => s.id === serviceId);
    setFormData((prev) => ({
      ...prev,
      serviceId,
      price: selected ? selected.price : 0,
      duration: selected ? selected.duration_minutes : 60,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createAppointment({
        client_full_name: formData.fullName,
        client_phone: formData.phone,
        client_email: formData.email,
        client_note: formData.clientNote,
        branch_id: formData.branchId,
        employee_id: formData.employeeId,
        service_id: formData.serviceId,
        appointment_date: new Date(formData.date).toISOString(),
        comment: formData.comment,
        status: formData.status,
      });

      onSuccess();
      onClose();
    } catch (err) {
      alert('Ошибка при создании записи');
      console.error(err);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-window">
        <div className="modal-header">
          <h2>Новая запись</h2>
          <button type="button" className="modal-close" onClick={onClose}>
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-form">
          <div className="form-row cols-3">
            <div className="form-group">
              <label>ФИО клиента*</label>
              <input
                type="text"
                placeholder="ФИО клиента"
                required
                value={formData.fullName}
                onChange={(e) =>
                  setFormData({ ...formData, fullName: e.target.value })
                }
              />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
              />
            </div>
            <div className="form-group">
              <label>Телефон*</label>
              <input
                type="text"
                placeholder="+7 ___ ___ __ __"
                required
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
              />
            </div>
          </div>

          <div className="form-row cols-3">
            <div className="form-group">
              <label>Филиал*</label>
              <select
                value={formData.branchId}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    branchId: Number(e.target.value),
                  })
                }
              >
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Выберите сотрудника*</label>
              <select
                required
                value={formData.employeeId}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    employeeId: Number(e.target.value),
                  })
                }
              >
                <option value="">Выберите сотрудника</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.full_name}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Услуга*</label>
              <select
                required
                value={formData.serviceId}
                onChange={(e) => handleServiceChange(Number(e.target.value))}
              >
                <option value="">Выберите услугу</option>
                {services.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-row cols-3">
            <div className="form-group">
              <label>Дата записи*</label>
              <input
                type="datetime-local"
                required
                value={formData.date}
                onChange={(e) =>
                  setFormData({ ...formData, date: e.target.value })
                }
              />
            </div>
            <div className="form-group">
              <label>Статус</label>
              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    status: e.target.value as any,
                  })
                }
              >
                <option value="booked">🟡 Записан</option>
                <option value="in_progress">🔵 В процессе</option>
                <option value="completed">🟢 Завершен</option>
                <option value="cancelled">🔴 Отменен</option>
              </select>
            </div>
            <div className="form-group">
              <label>Цена (₸)</label>
              <input
                type="number"
                value={formData.price}
                onChange={(e) =>
                  setFormData({ ...formData, price: Number(e.target.value) })
                }
              />
            </div>
          </div>

          <div className="form-row cols-3">
            <div className="form-group">
              <label>Длительность, минут*</label>
              <input
                type="number"
                required
                value={formData.duration}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    duration: Number(e.target.value),
                  })
                }
              />
            </div>
            <div className="form-group">
              <label>Источник</label>
              <input type="text" placeholder="Источник" />
            </div>
            <div className="form-group">
              <label>Напоминание клиенту</label>
              <select>
                <option>Не напоминать</option>
              </select>
            </div>
          </div>

          <div className="form-group full-width">
            <label>Комментарий к записи:</label>
            <textarea
              rows={3}
              placeholder="Комментарий к записи"
              value={formData.comment}
              onChange={(e) =>
                setFormData({ ...formData, comment: e.target.value })
              }
            ></textarea>
          </div>

          <div className="form-group full-width">
            <label>Заметка в карточке о клиенте</label>
            <textarea
              rows={3}
              placeholder="Заметка в карточке о клиенте"
              value={formData.clientNote}
              onChange={(e) =>
                setFormData({ ...formData, clientNote: e.target.value })
              }
            ></textarea>
          </div>

          <div className="modal-footer">
            <button
              type="button"
              className="btn-secondary"
              onClick={onClose}
            >
              Закрыть
            </button>
            <button type="submit" className="btn-success">
              💾 Создать запись
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const AppointmentsPage: React.FC<AppointmentsPageProps> = ({
  onOpenModal,
  refreshTrigger,
}) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedBranch, setSelectedBranch] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const loadData = async () => {
    const apps = await getAppointments();
    const brs = await getBranches();
    setAppointments(apps);
    setBranches(brs);

    if (brs.length > 0 && !selectedBranch) {
      setSelectedBranch(brs[0].id);
    }
  };

  useEffect(() => {
    loadData();
  }, [refreshTrigger]);

  useEffect(() => {
    if (selectedBranch) {
      getEmployeesByBranch(selectedBranch).then(setEmployees);
    }
  }, [selectedBranch]);

  const handleOpenModal = () => {
    setIsModalOpen(true);
    if (onOpenModal) onOpenModal();
  };

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00',
    '11:30', '12:00', '12:30', '13:00', '13:30',
    '14:00', '14:30', '15:00', '15:30', '16:00',
    '16:30', '17:00', '17:30', '18:00'
  ];

  return (
    <div className="app-layout">
      <header className="journal-header">
        <div className="journal-header__left">
          <h1 className="journal-title">Журнал записей</h1>
          <select
            className="journal-select"
            value={selectedBranch || ''}
            onChange={(e) => setSelectedBranch(Number(e.target.value))}
          >
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>

        <div className="journal-header__controls">
          <div className="nav-buttons">
            <button className="btn-nav" type="button">&lt;</button>
            <button className="btn-nav" type="button">&gt;</button>
            <button className="btn-today" type="button">Сегодня</button>
          </div>
          <button
            className="btn-primary"
            type="button"
            onClick={handleOpenModal}
          >
            + Создать запись
          </button>
          <div className="view-switch">
            <button className="view-btn active" type="button">День</button>
            <button className="view-btn" type="button">Неделя</button>
            <button className="view-btn" type="button">Месяц</button>
            <button className="view-btn" type="button">Доска</button>
          </div>
        </div>
      </header>

      <div className="journal-grid-wrapper">
        <div className="journal-grid">
          <div className="grid-header">
            <div className="time-col-header">Время</div>
            {employees.map((emp) => (
              <div key={emp.id} className="employee-card-header">
                <div className="emp-avatar">
                  {emp.full_name ? emp.full_name.charAt(0) : 'E'}
                </div>
                <div className="emp-info">
                  <div className="emp-name">{emp.full_name}</div>
                  <div className="emp-sub">
                    {branches.find((b) => b.id === selectedBranch)?.name || 'Филиал'}
                  </div>
                  <div className="emp-sub">
                    {emp.work_time || '09:00 - 18:00'}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid-body">
            {timeSlots.map((time) => (
              <div key={time} className="time-row">
                <div className="time-label">{time}</div>

                {employees.map((emp) => {
                  const appointment = appointments.find((a) => {
                    if (a.employee_id !== emp.id) return false;
                    const appTime = new Date(a.appointment_date).toLocaleTimeString('ru-RU', {
                      hour: '2-digit',
                      minute: '2-digit',
                    });
                    return appTime === time;
                  });

                  return (
                    <div key={emp.id} className="time-cell">
                      {appointment && (
                        <div className="appointment-card">
                          <div className="app-time-header">
                            {time}
                            {appointment.services?.duration_minutes
                              ? ` (${appointment.services.duration_minutes} мин)`
                              : ''}
                          </div>
                          <div className="app-body">
                            <div className="app-client-row">
                              <span className="app-status-dot"></span>
                              <strong className="app-client-name">
                                {appointment.clients?.full_name || 'Неизвестный клиент'}
                              </strong>
                            </div>
                            <div className="app-detail">
                              Услуга: {appointment.services?.name || '—'}
                            </div>
                            <div className="app-detail">
                              Статус: {appointment.status || 'Записан'}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      <AppointmentModalInternal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={loadData}
      />
    </div>
  );
};

export default AppointmentsPage;