import React, { useEffect, useState } from 'react';
import {
  getAppointments,
  getBranches,
  getEmployeesByBranch,
} from '../../service/appointments';
import type {
  Appointment,
  Branch,
  Employee,
} from '../../service/appointments';
import './AppointmentsPage.css';

interface AppointmentsPageProps {
  onOpenModal: () => void;
  refreshTrigger?: number;
}

export const AppointmentsPage: React.FC<AppointmentsPageProps> = ({
  onOpenModal,
  refreshTrigger,
}) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedBranch, setSelectedBranch] = useState<number | null>(null);

  const loadData = async () => {
    const apps = await getAppointments();
    const brs = await getBranches();
    setAppointments(apps);
    setBranches(brs);

    if (brs.length > 0 && !selectedBranch) {
      setSelectedBranch(brs[0].id);
    }
  };

  useEffect(() => {
    loadData();
  }, [refreshTrigger]);

  useEffect(() => {
    if (selectedBranch) {
      getEmployeesByBranch(selectedBranch).then(setEmployees);
    }
  }, [selectedBranch]);

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', 
    '11:30', '12:00', '12:30', '13:00', '13:30', 
    '14:00', '14:30', '15:00', '15:30', '16:00', 
    '16:30', '17:00', '17:30', '18:00'
  ];

  const currentBranchName =
    branches.find((b) => b.id === selectedBranch)?.name || 'Филиал';

  return (
    <div className="app-layout">
      <header className="journal-header">
        <div className="journal-header__left">
          <h1 className="journal-title">Журнал записей</h1>
          <select
            className="journal-select"
            value={selectedBranch || ''}
            onChange={(e) => setSelectedBranch(Number(e.target.value))}
          >
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>

        <div className="journal-header__controls">
          <div className="nav-buttons">
            <button className="btn-nav" type="button">&lt;</button>
            <button className="btn-nav" type="button">&gt;</button>
            <button className="btn-today" type="button">Сегодня</button>
          </div>
          <button className="btn-primary" type="button" onClick={onOpenModal}>
            + Создать запись
          </button>
          <div className="view-switch">
            <button className="view-btn active" type="button">День</button>
            <button className="view-btn" type="button">Неделя</button>
            <button className="view-btn" type="button">Месяц</button>
            <button className="view-btn" type="button">Доска</button>
          </div>
        </div>
      </header>

      <div className="journal-grid-wrapper">
        <div className="journal-grid">
          {/* Шапка сетки с сотрудниками */}
          <div className="grid-header">
            <div className="time-col-header">Время</div>
            {employees.map((emp) => (
              <div key={emp.id} className="employee-card-header">
                <div className="emp-avatar">
                  {emp.full_name ? emp.full_name.charAt(0) : 'E'}
                </div>
                <div className="emp-info">
                  <div className="emp-name">{emp.full_name}</div>
                  <div className="emp-sub">{currentBranchName}</div>
                  <div className="emp-sub">
                    {emp.work_time || '09:00 - 18:00'}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Тело сетки с временными слотами */}
          <div className="grid-body">
            {timeSlots.map((time) => (
              <div key={time} className="time-row">
                <div className="time-label">{time}</div>

                {employees.map((emp) => {
                  const appointment = appointments.find((a) => {
                    if (a.employee_id !== emp.id) return false;
                    const appTime = new Date(a.appointment_date).toLocaleTimeString('ru-RU', {
                      hour: '2-digit',
                      minute: '2-digit',
                    });
                    return appTime === time;
                  });

                  return (
                    <div key={emp.id} className="time-cell">
                      {appointment && (
                        <div className="appointment-card">
                          <div className="app-time-header">
                            {time}
                            {appointment.services?.duration_minutes
                              ? ` (${appointment.services.duration_minutes} мин)`
                              : ''}
                          </div>
                          <div className="app-body">
                            <div className="app-client-row">
                              <span className="app-status-dot"></span>
                              <strong className="app-client-name">
                                {appointment.clients?.full_name || 'Неизвестный клиент'}
                              </strong>
                            </div>
                            <div className="app-detail">
                              Услуга: {appointment.services?.name || '—'}
                            </div>
                            <div className="app-detail">
                              Статус: {appointment.status || 'Записан'}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppointmentsPage;