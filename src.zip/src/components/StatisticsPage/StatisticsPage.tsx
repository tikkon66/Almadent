import React, { useState } from 'react';
import './StatisticsPage.css';

export const StatisticsPage: React.FC = () => {
  // Состояние фильтров
  const [filters, setFilters] = useState({
    dateRecordFrom: '',
    dateRecordTo: '',
    dateCreatedFrom: '',
    dateCreatedTo: '',
    recordNumber: '',
    clientName: '',
    email: '',
    phone: '',
    clientComment: '',
    status: 'all',
    branch: 'all',
    employee: 'all',
    service: 'all',
    createdBy: 'any',
    usePromo: 'ignore',
    promoCode: '',
    membership: '',
    source: '',
    displayMode: 'days',
    chartType: 'line',
    cancelReason: 'any',
    paymentNeed: 'ignore',
    paymentDone: 'ignore',
    paymentBank: 'ignore',
    newClient: 'all',
  });

  // Обработчик изменения полей
  const handleChange = (field: string, value: string) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="stats-page">
      {/* Шапка страницы */}
      <div className="stats-header">
        <h1 className="stats-header__title">Статистика</h1>
      </div>

      {/* Сетка фильтров */}
      <div className="stats-filters">
        <div className="stats-filters__grid">
          {/* Строка 1 */}
          <div className="filter-group">
            <label>Дата записи, от</label>
            <input
              type="date"
              value={filters.dateRecordFrom}
              onChange={(e) => handleChange('dateRecordFrom', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Дата записи, до</label>
            <input
              type="date"
              value={filters.dateRecordTo}
              onChange={(e) => handleChange('dateRecordTo', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Дата создания, от</label>
            <input
              type="date"
              value={filters.dateCreatedFrom}
              onChange={(e) => handleChange('dateCreatedFrom', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Дата создания, до</label>
            <input
              type="date"
              value={filters.dateCreatedTo}
              onChange={(e) => handleChange('dateCreatedTo', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Номер записи</label>
            <input
              type="text"
              placeholder="Номер записи"
              value={filters.recordNumber}
              onChange={(e) => handleChange('recordNumber', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>ФИО клиента</label>
            <input
              type="text"
              placeholder="ФИО клиента"
              value={filters.clientName}
              onChange={(e) => handleChange('clientName', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Email</label>
            <input
              type="text"
              placeholder="Email"
              value={filters.email}
              onChange={(e) => handleChange('email', e.target.value)}
            />
          </div>

          {/* Строка 2 */}
          <div className="filter-group">
            <label>Телефон</label>
            <input
              type="text"
              placeholder="Телефон"
              value={filters.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label className="label-highlight">Комментарий клиента</label>
            <input
              type="text"
              placeholder="Комментарий клиента"
              value={filters.clientComment}
              onChange={(e) => handleChange('clientComment', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label className="label-highlight">Статус</label>
            <select
              value={filters.status}
              onChange={(e) => handleChange('status', e.target.value)}
            >
              <option value="all">Все</option>
              <option value="booked">Записан</option>
              <option value="in_progress">В процессе</option>
              <option value="completed">Завершен</option>
              <option value="cancelled">Отменен</option>
            </select>
          </div>

          <div className="filter-group">
            <label className="label-highlight">Филиал</label>
            <select
              value={filters.branch}
              onChange={(e) => handleChange('branch', e.target.value)}
            >
              <option value="all">Все</option>
            </select>
          </div>

          <div className="filter-group">
            <label className="label-highlight">Сотрудник</label>
            <select
              value={filters.employee}
              onChange={(e) => handleChange('employee', e.target.value)}
            >
              <option value="all">Все</option>
            </select>
          </div>

          <div className="filter-group">
            <label className="label-highlight">Услуга</label>
            <select
              value={filters.service}
              onChange={(e) => handleChange('service', e.target.value)}
            >
              <option value="all">Все</option>
            </select>
          </div>

          <div className="filter-group">
            <label className="label-highlight">Кем создана запись</label>
            <select
              value={filters.createdBy}
              onChange={(e) => handleChange('createdBy', e.target.value)}
            >
              <option value="any">-- любым --</option>
              <option value="client">Клиентом</option>
              <option value="admin">Администратором</option>
            </select>
          </div>

          {/* Строка 3 */}
          <div className="filter-group">
            <label>Использован промокод</label>
            <select
              value={filters.usePromo}
              onChange={(e) => handleChange('usePromo', e.target.value)}
            >
              <option value="ignore">-- не учитывать --</option>
              <option value="yes">Да</option>
              <option value="no">Нет</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Промокод</label>
            <input
              type="text"
              placeholder="Промокод"
              value={filters.promoCode}
              onChange={(e) => handleChange('promoCode', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Абонемент</label>
            <input
              type="text"
              placeholder="Абонемент"
              value={filters.membership}
              onChange={(e) => handleChange('membership', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Источник</label>
            <input
              type="text"
              placeholder="Источник"
              value={filters.source}
              onChange={(e) => handleChange('source', e.target.value)}
            />
          </div>

          <div className="filter-group">
            <label>Режим отображения</label>
            <select
              value={filters.displayMode}
              onChange={(e) => handleChange('displayMode', e.target.value)}
            >
              <option value="days">По дням</option>
              <option value="weeks">По неделям</option>
              <option value="months">По месяцам</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Тип графика</label>
            <select
              value={filters.chartType}
              onChange={(e) => handleChange('chartType', e.target.value)}
            >
              <option value="line">Линейный</option>
              <option value="bar">Столбчатый</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Причина отмены записи</label>
            <select
              value={filters.cancelReason}
              onChange={(e) => handleChange('cancelReason', e.target.value)}
            >
              <option value="any">-- Любая --</option>
            </select>
          </div>

          {/* Строка 4 */}
          <div className="filter-group">
            <label>Необходимость оплаты</label>
            <select
              value={filters.paymentNeed}
              onChange={(e) => handleChange('paymentNeed', e.target.value)}
            >
              <option value="ignore">-- не учитывать --</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Оплата выполнена</label>
            <select
              value={filters.paymentDone}
              onChange={(e) => handleChange('paymentDone', e.target.value)}
            >
              <option value="ignore">-- не учитывать --</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Оплата через банк</label>
            <select
              value={filters.paymentBank}
              onChange={(e) => handleChange('paymentBank', e.target.value)}
            >
              <option value="ignore">-- не учитывать --</option>
            </select>
          </div>

          <div className="filter-group">
            <label>Новый клиент</label>
            <select
              value={filters.newClient}
              onChange={(e) => handleChange('newClient', e.target.value)}
            >
              <option value="all">Все</option>
              <option value="yes">Да</option>
              <option value="no">Нет</option>
            </select>
          </div>

          {/* Кнопка фильтрации */}
          <div className="filter-group filter-group--btn">
            <button className="btn btn--filter">🔍 Фильтровать</button>
          </div>
        </div>

        {/* Дополнительные действия под фильтрами */}
        <div className="stats-actions">
          <button className="btn btn--action-blue">
            ↺ История изменения записей
          </button>
          <button className="btn btn--action-blue">
            🔔 Запросы оповещений
          </button>
          <button className="btn btn--action-outline">
            💾 Экспортировать записи
          </button>
        </div>
      </div>

      {/* Итоговая строка данных */}
      <div className="stats-summary">
        Записей: <strong>3</strong>. Стоимость услуг: <strong>2100</strong>. Длительность услуг, минут: <strong>180</strong>.
      </div>

      {/* График и легенда */}
      <div className="stats-chart-card">
        <div className="chart-legend">
          <div className="legend-item">
            <span className="legend-color legend-color--purple"></span>
            <span>Записей</span>
          </div>
          <div className="legend-item">
            <span className="legend-color legend-color--cyan"></span>
            <span>Стоимость услуг</span>
          </div>
          <div className="legend-item">
            <span className="legend-color legend-color--pink"></span>
            <span>Длительность услуг, минут</span>
          </div>
        </div>

        {/* Область отображения графика */}
        <div className="chart-wrapper">
          <div className="chart-y-axis">
            <span>2500</span>
            <span>2000</span>
            <span>1500</span>
            <span>1000</span>
            <span>500</span>
            <span>0</span>
          </div>

          <div className="chart-canvas">
            <div className="chart-grid-line" style={{ top: '0%' }}></div>
            <div className="chart-grid-line" style={{ top: '20%' }}></div>
            <div className="chart-grid-line" style={{ top: '40%' }}></div>
            <div className="chart-grid-line" style={{ top: '60%' }}></div>
            <div className="chart-grid-line" style={{ top: '80%' }}></div>
            <div className="chart-grid-line" style={{ top: '100%' }}></div>

            {/* Пример нарисованного графика/точки */}
            <svg className="chart-svg">
              <polyline
                fill="none"
                stroke="#06b6d4"
                strokeWidth="2"
                points="0,95 200,80 400,98 600,98 800,98"
              />
              <circle cx="0" cy="95" r="4" fill="#06b6d4" />
            </svg>
            <div className="chart-y-label">По дням</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatisticsPage;