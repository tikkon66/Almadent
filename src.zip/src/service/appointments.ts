 import { supabase } from './supabase'; // Путь к вашему клиенту Supabase

export interface Branch {
  id: number;
  name?: string;
  address?: string;
}

export interface Employee {
  id: number;
  branch_id: number;
  full_name: string;
  position?: string;
  work_time?: string;
}

export interface Service {
  id: number;
  branch_id: number;
  name: string;
  price: number;
  duration_minutes: number;
}

export interface Appointment {
  id: number;
  client_id: number;
  branch_id: number;
  employee_id: number;
  service_id: number;
  appointment_date: string;
  comment?: string;
  status?: string;
  clients?: { full_name: string; phone?: string; email?: string };
  branches?: { address: string };
  employees?: { full_name: string };
  services?: { name: string; price: number; duration_minutes: number };
}

export interface CreateAppointmentDTO {
  client_full_name: string;
  client_phone: string;
  client_email?: string;
  client_note?: string;
  branch_id: number;
  employee_id: number;
  service_id: number;
  appointment_date: string;
  comment?: string;
  status?: string;
}

// Получить все записи с расширенными данными
export const getAppointments = async (): Promise<Appointment[]> => {
  const { data, error } = await supabase
    .from('appointments')
    .select(`
      *,
      clients ( full_name, phone, email ),
      branches ( address ),
      employees ( full_name ),
      services ( name, price, duration_minutes )
    `);

  if (error) {
    console.error('Ошибка при получении записей:', error);
    return [];
  }
  return data || [];
};

// Получить список филиалов
export const getBranches = async (): Promise<Branch[]> => {
  const { data, error } = await supabase
    .from('branches')
    .select('id, address');

  if (error) {
    console.error('Ошибка при получении филиалов:', error);
    return [];
  }

  return (data || []).map((b) => ({
    id: b.id,
    name: b.address,
    address: b.address,
  }));
};

// Получить сотрудников филиала
export const getEmployeesByBranch = async (branchId: number): Promise<Employee[]> => {
  const { data, error } = await supabase
    .from('employees')
    .select('*')
    .eq('branch_id', branchId);

  if (error) {
    console.error('Ошибка при получении сотрудников:', error);
    return [];
  }
  return data || [];
};

// Получить услуги филиала
export const getServicesByBranch = async (branchId: number): Promise<Service[]> => {
  const { data, error } = await supabase
    .from('services')
    .select('*')
    .eq('branch_id', branchId);

  if (error) {
    console.error('Ошибка при получении услуг:', error);
    return [];
  }
  return data || [];
};

// Создать новую запись и при необходимости привязать/создать клиента
export const createAppointment = async (dto: CreateAppointmentDTO) => {
  // 1. Поиск или создание клиента
  let clientId: number;
  
  const { data: existingClient } = await supabase
    .from('clients')
    .select('id')
    .eq('phone', dto.client_phone)
    .maybeSingle();

  if (existingClient) {
    clientId = existingClient.id;
  } else {
    const { data: newClient, error: clientErr } = await supabase
      .from('clients')
      .insert([
        {
          full_name: dto.client_full_name,
          phone: dto.client_phone,
          email: dto.client_email,
          note: dto.client_note,
        },
      ])
      .select('id')
      .single();

    if (clientErr || !newClient) {
      throw new Error('Не удалось создать карточку клиента');
    }
    clientId = newClient.id;
  }

  // 2. Создание записи
  const { data, error } = await supabase
    .from('appointments')
    .insert([
      {
        client_id: clientId,
        branch_id: dto.branch_id,
        employee_id: dto.employee_id,
        service_id: dto.service_id,
        appointment_date: dto.appointment_date,
        comment: dto.comment,
        status: dto.status || 'booked',
      },
    ])
    .select();

  if (error) {
    console.error('Ошибка при создании записи:', error);
    throw error;
  }

  return data;
};